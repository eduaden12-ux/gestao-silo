import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner tecla = new Scanner(System.in);
        
        int opcao = -1 ;
        int id = 0;
        int sacas = 0;
        String grao = "";
        
        int idcarga = 0;
        String graocarga = " ";
        
      
        String idsoja = "001";
        String idmilho = "002";
        String idtrigo = "003";
        
        int estoquedispomilho = 0;
        int estoquedisposoja = 0;
        int estoquedispotrigo = 0;
        int capacidadesoja = 500;
        int capacidademilho = 1000;
        int capacidadetrigo = 700;
        int sacascargamilho = 0;
        int sacascargasoja = 0;
        int sacascargatrigo = 0;
        
        while(opcao !=0){
            System.out.println("=====================================================");
            System.out.println("          SISTEMA DE GESTAO DE SILOS - V1.0          ");
            System.out.println("=====================================================");
            
             System.out.println("1 - cadastro de silo\n2 - entrada de carga\n3 - saida de carga\n4 - ver estoque");
             System.out.println("digita sua escolha: ");
             opcao = tecla.nextInt();
             
             if(opcao==1){
                System.out.println("=====================================================");
                System.out.println("                   CADASTRO                          ");
                System.out.println("=====================================================");
                System.out.println("ID DO SILO: ");
                id = tecla.nextInt();
                
                
                System.out.println("PESO EM SACAS: ");
                sacas = tecla.nextInt();
                
                tecla.nextLine();
                System.out.println("TIPO DE GRAO(soja,milho,trigo): ");
                grao = tecla.nextLine();
                
                
                
             }else if(opcao == 2){
                String opcaoentrada ="sim";
                while(opcaoentrada.equals("sim")){
                    System.out.println("=====================================================");
                    System.out.println("                   ENTRADA DE CARGA                ");
                    System.out.println("=====================================================");
                    System.out.println("ID DO SILO (soja - "+idsoja+"| milho - "+idmilho+" | trigo - "+idtrigo+"): ");
                    id = tecla.nextInt();
                    
                    tecla.nextLine();
                    System.out.println("TIPO DE GRAO(soja ,milho,trigo): ");
                     grao = tecla.nextLine();
                    
                    
                    if(grao.equals("milho")){
                        System.out.println("quantidade de SACAS a entrar: ");
                        sacascargamilho = tecla.nextInt();
                        if(estoquedispomilho + sacascargamilho  <= capacidademilho ){
                            System.out.println("carga liberada");
                            estoquedispomilho += sacascargamilho;
                        }else if(sacascargamilho > estoquedispomilho){
                            System.out.println("carga barrada estoque cheio⚠⚠⚠");
                        }
                    }else if(grao.equals("soja")){
                            System.out.println("quantidade de SACAS a entrar: ");
                            sacascargasoja = tecla.nextInt();
                            if(estoquedisposoja + sacascargasoja <= capacidadesoja ){
                                estoquedisposoja += sacascargasoja;
                                System.out.println("carga liberada");
                            }else if(sacascargasoja > estoquedisposoja){
                                System.out.println("carga barrada estoque cheio⚠⚠⚠");
                            }
                    }else if(grao.equals("trigo")){
                            System.out.println("quantidade de SACAS a entrar: ");
                            sacascargatrigo = tecla.nextInt();
                            if(estoquedispotrigo + sacascargatrigo <= capacidadetrigo ){
                                estoquedispotrigo += sacascargatrigo;
                                System.out.println("carga liberada");
                            }else if(sacascargatrigo > estoquedispotrigo){
                                System.out.println("carga barrada estoque cheio⚠⚠⚠");
                            }
                    }

                    System.out.print("ira entrar mais carga: ");
                    tecla.nextLine();
                    opcaoentrada = tecla.nextLine();
                    if(opcaoentrada.equals("sim")){
                        opcaoentrada = "sim";
                    }else if(opcaoentrada.equals("nao")){
                        opcaoentrada = "nao";
                    }
                    
                
                }
                
                 
             }else if(opcao==3){
                System.out.println("=====================================================");
                System.out.println("                    SAIDA DE CARGA                  ");
                System.out.println("=====================================================");
                System.out.println("ID DO SILO (soja - "+idsoja+"milho - "+idmilho+"trigo - "+idtrigo+"): ");
                id = tecla.nextInt();
                
                tecla.nextLine();
                System.out.println("TIPO DE GRAO(soja ,milho,trigo): ");
                 grao = tecla.nextLine();
                
                
                if(grao.equals("milho")){
                    System.out.println("quantidade de SACAS a sair: ");
                    sacascargamilho = tecla.nextInt();
                    if(sacascargamilho > 0 && sacascargamilho  <= estoquedispomilho ){
                        System.out.println("carga liberada");
                        estoquedispomilho -= sacascargamilho;
                    }else if(sacascargamilho > estoquedispomilho){
                        System.out.println("carga barrada estoque vazio⚠⚠⚠");
                    }
                }else if(grao.equals("soja")){
                    System.out.println("quantidade de SACAS a sair: ");
                    sacascargasoja = tecla.nextInt();
                    if(sacascargasoja > 0 && sacascargasoja  <= estoquedisposoja ){
                        estoquedisposoja -= sacascargasoja;
                        System.out.println("carga liberada");
                    }else if(sacascargasoja > estoquedisposoja){
                        System.out.println("carga barrada estoque vazio⚠⚠⚠");
                    }
                }else if(grao.equals("trigo")){
                    System.out.println("quantidade de SACAS a sair: ");
                    sacascargatrigo = tecla.nextInt();
                    if(sacascargatrigo > 0 && sacascargatrigo  <= estoquedispotrigo ){
                        estoquedispotrigo -= sacascargatrigo;
                        System.out.println("carga liberada");
                    }else if(sacascargatrigo > estoquedispotrigo){
                        System.out.println("carga barrada estoque vazio⚠⚠⚠");
                    }
                }  
                
                
             }else if(opcao==4){
                System.out.println("=====================================================");
                System.out.println("                    ESTOQUE                          ");
                System.out.println("=====================================================");
                System.out.println(" ID |001"+       "     | GRAO | soja"+ "      | estoque(sacas)"+estoquedisposoja);
                System.out.println(" ID |002"+       "     | GRAO | milho"+ "     | estoque(sacas)"+estoquedispomilho);
                System.out.println(" ID |003"+       "     | GRAO | trigo"+ "     | estoque(sacas)"+estoquedispotrigo);
                
             }
         
        }
        
    }
}
